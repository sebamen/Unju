<?php
    echo "<center><h1>Trabajo Práctico Nº 4</h1></center>";
    echo "<center>********************************************</center>";
    echo "<br>";
    echo "<center><h3>Autor: Sebastián Menéndez</h3></center>";
    echo "<br><br><br>";
?>