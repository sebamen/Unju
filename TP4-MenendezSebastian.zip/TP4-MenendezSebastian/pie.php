<?php
    echo "<center><h1>Fin Trabajo Práctico Nº 4</h1></center>";
    echo "<center>********************************************</center>";
    echo "<br>";
    echo "<center><h3>Tema: Funciones PHP</h3></center>";
    echo "<br><br><br>";
?>