<?php
    echo "<center><h1>Fin Trabajo Práctico Nº 3</h1></center>";
    echo "<center>********************************************</center>";
    echo "<br>";
    echo "<center><h3>Tema: Funciones en PHP</h3></center>";
    echo "<br><br><br>";
?>